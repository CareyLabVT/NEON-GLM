#include "duckdb/catalog/catalog_entry.hpp"

#include "duckdb/catalog/catalog.hpp"

namespace duckdb {
using namespace std;

CatalogEntry::~CatalogEntry() {
}

} // namespace duckdb
